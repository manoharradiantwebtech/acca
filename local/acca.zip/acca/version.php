<?php
defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2024011702;   // YYYYMMDDHH (year, month, day, hour)
$plugin->requires  = 2018051501;   // Moodle version
$plugin->component = 'local_acca';
