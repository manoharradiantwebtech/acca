<?php
$string['pluginname'] = 'ACCA Plugin';
